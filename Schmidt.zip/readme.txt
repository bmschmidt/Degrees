Generated table is based on the following variables:
Data source(s):
	IPEDS Completions Survey

Analysis variables: 
	Sum of Degrees/Awards Conferred (NCES population of institutions)

Classification variables:
-Year
	Filter for following values: All values

-Gender
	Filter for following values: All values

-Level of Degree or Other Award
	Filter for following values: Associate's Degrees; Bachelor's Degrees; Doctorate Degrees; Master's Degrees

-Academic Discipline, Detailed (standardized)
	Filter for following values: All values

-Academic Institution (standardized)
	Filter for following values: Babson College; Bates College; Boston College; Boston University; Bowdoin College; Brandeis University; Brigham Young University, Main Campus; Brown University; California State Polytechnic U-San Luis Obispo; California State University-Bakersfield; California State University-Fresno; California State University-Fullerton; California State University-Los Angeles; City University; Clark University; Colby College; College of the Holy Cross; Cornell University, All Campuses; Dartmouth College; Drexel University; Emory University; Fisk University; Fitchburg State College; George Mason University; Georgetown University; Harvard University; Haverford College; Howard University; Lesley College; Massachusetts Institute of Technology; Miami-Dade Community College; Michigan State University; New York University; Northwestern Univ; Ohio State University, Main Campus; Princeton University; Rensselaer Polytechnic Institute; Rice University; Richard Stockton College of New Jersey; Rutgers the State Univ of NJ New Brunswick; Salem State College; Smith College; Southern Methodist University; St Olaf College; Stanford University; Stevens Institute of Technology; Texas A&M University Main Campus; Tufts University; University of California-Berkeley; University of California-Davis; University of California-Irvine; University of California-Los Angeles; University of Chicago; University of Colorado at Boulder; University of Colorado at Denver; University of Connecticut; University of Connecticut, All Campuses; University of Georgia; University of Illinois at Chicago; University of Illinois at Urbana-Champaign; University of Iowa; University of Maine; University of Maryland at College Park; University of Massachusetts Lowell; University of Massachusetts at Amherst; University of Massachusetts at Boston; University of Massachusetts at Dartmouth; University of Michigan at Ann Arbor; University of Minnesota - Duluth; University of Minnesota - Twin Cities; University of Nebraska at Lincoln; University of Pennsylvania; University of Rhode Island; University of Southern Maine; University of Texas at Arlington; University of Texas at Austin; University of Texas at Dallas; University of Texas at Permian Basin; University of Virginia, Main Campus; University of Washington - Seattle; University of Wisconsin-Madison; University of Wisconsin-Milwaukee; Washington University; Wellesley College; Williams College; Yale University


Table was created by the WebCaspar website (http://webcaspar.nsf.gov) on Fri, 2 Aug 2013 17:40 -0400